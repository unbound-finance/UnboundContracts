#!/usr/bin/python3

import sys
import os
import json
import ast
from pyfirefly.transactionGeneration import generate_random_value, get_printable_func


class Customize:
    # TODO: Might modify this class for different projects
    # Pre-defined format for filename
    format = ["00_", ".blackbox.test.js"]
    # Common import requirements for test js files
    pre_import = "const BigNumber = web3.BigNumber;\nrequire('chai')\n.use(require('chai-bignumber')(BigNumber))\n.should();\n"



def parse_raw_test(raw_test, tests_list):
    ''' Parse raw test in JSON and append to tests_list in corresponding key '''
    # Format: { func_name:..., func_args:[...] }
    contract_name = raw_test["contract"]
    func_name = raw_test["func_name"]
    func_args = raw_test["func_args"]

    new_test = {"func_name": func_name, "func_args": func_args}
    if contract_name not in tests_list:
        tests_list[contract_name] = [new_test]
    else:
        tests_list[contract_name].append(new_test)


def write_it_test(f, contract_name, func, constructor_info, num_tabs=2):
    ''' Write a single test in "it" cell into js file '''
    f.write("\t" * num_tabs + "it('call func " + func["func_name"] + " with blackbox random args', async () => {\n")
    f.write("\t" * (num_tabs + 1) + "// Might adjust constructor accordingly\n")
    # Generate appropiate constructor
    constructor_args = ""
    if len(constructor_info[contract_name]) != 0:
        cons_arg = []
        for cons_raw in constructor_info[contract_name]:
            arg_type = cons_raw["type"]
            cons_arg.append(get_printable_func(arg_type)(generate_random_value(arg_type)))
        constructor_args = ", ".join("\"" + str(arg) + "\"" for arg in cons_arg)

    f.write("\t" * (num_tabs + 1) + "const obj = await " + contract_name + ".new(" + constructor_args + ");\n")
    arg_cnt = 0
    arg_list = []
    for arg in func["func_args"]:
        if arg[0] == '[' and arg[-1] == ']':
            # This argument is a list
            sub_arg_list = arg[1:-1].split(", ")
            f.write("\t" * (num_tabs + 1) + "const arg" + str(arg_cnt) + " = [" + ", ".join(("\"" + str(sub_arg).replace('"', '\\"') + "\"") for sub_arg in sub_arg_list) + "];\n")
        else:
            # This argument is a normal arg
            f.write("\t" * (num_tabs + 1) + "const arg" + str(arg_cnt) + " = \"" + str(arg).replace('"', '\\"') + "\";\n")
        arg_list.append("arg" + str(arg_cnt))
        arg_cnt += 1
    
    f.write("\t" * (num_tabs + 1) + "const res = await obj." + func["func_name"] + "(" + ", ".join(arg_list) + ");\n")
    f.write("\t" * (num_tabs + 1) + "expect(0).to.equal(0);\n")
    f.write("\t" * (num_tabs + 1) + "// TODO: FILL IN POST CONDITION/ASSERTIONS HERE\n")
    f.write("\t" * num_tabs + "});\n\n")


def write_test_js_files(tests_list, constructor_info, output_dir):
    ''' Dump all tests into js files '''
    for contract_name, func_list in tests_list.items():
        file_name = os.path.join(output_dir, Customize.format[0] + contract_name + Customize.format[1])
        with open(file_name, "w") as f:
            f.write("// This is the automatically generated test file for contract: " + contract_name + "\n")
            f.write("// Other libraries might be imported here\n\n")
            f.write(Customize.pre_import + "\n")
            f.write("const " + contract_name + " = artifacts.require('" + contract_name + "');\n\n")
            f.write("contract('" + contract_name + "', (accounts) => {\n")
            f.write("\t// Coverage imporvement tests for " + contract_name + "\n")
            f.write("\tdescribe('" + contract_name + "BlackboxTest', () => {\n")
            for func in func_list:
                write_it_test(f, contract_name, func, constructor_info)
            f.write("\t});\n")
            f.write("});")


def generate_test(blackbox_random: list, constructor_info: dict, output_dir: str):
    if not os.path.isdir(output_dir):
        raise Exception("Error in opening output directory: " + output_dir)
        sys.exit(2)

    tests_list = {}
    for raw_test in blackbox_random:
        parse_raw_test(raw_test, tests_list)

    write_test_js_files(tests_list, constructor_info, output_dir)
