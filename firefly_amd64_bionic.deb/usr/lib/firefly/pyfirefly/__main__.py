#!/usr/bin/python3

import argparse
import sys
import json
from pyfirefly.fetchFunctionData import fetch_function_data
from pyfirefly.testGeneration import generate_test


def make_parser():
    parser = argparse.ArgumentParser()
    subprasers = parser.add_subparsers(dest='command')

    funcDataParser = subprasers.add_parser('funcData', help = 'Obtain function data.')
    funcDataParser.add_argument('arg', nargs='*', help = 'Path of function-data input json file.')

    genTestParser = subprasers.add_parser('genTest', help = 'Generate js test files.')
    genTestParser.add_argument('arg', nargs='*', help = 'Path of blackbox_random.json and test output directory.')

    return parser


if __name__ == '__main__':
    parser = make_parser()
    args = parser.parse_args()
    
    if args.command == 'funcData':
        result = fetch_function_data(args.arg[0])
        sys.stdout.write(json.dumps(result, indent=4, sort_keys=True)+'\n')
        sys.stdout.flush()
