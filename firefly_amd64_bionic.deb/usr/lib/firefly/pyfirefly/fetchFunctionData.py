#!/usr/bin/python3

import sys
import os
import json
from Crypto.Hash import keccak


def generate_signature(fname: str, args: list) -> str:
    data = fname + "(" + ",".join([x["type"] for x in args]) + ")"
    data_hash = keccak.new(digest_bits=256)
    data_hash.update(data.encode("utf-8"))
    return "0x" + data_hash.hexdigest()[0:8]


def process_file(file: str) -> dict:
    out_dict = {}
    with open(file, "r") as in_file:
        in_dict = json.load(in_file)
        out_dict["contractName"] = in_dict["contractName"]
        out_dict["contractConstructor"] = [
            {
                "name": in_dict["contractName"],
                "signatureHash": generate_signature(in_dict["contractName"], x["inputs"]),
                "input": [
                    {"name": y["name"], "type": y["type"]} for y in x["inputs"]
                ]
            }
            for x in in_dict["abi"]
            if x["type"] == "constructor"
        ]
        out_dict["functionData"] = [
            {
                "name": x["name"],
                "signatureHash": generate_signature(x["name"], x["inputs"]),
                "input": [
                    {"name": y["name"], "type": y["type"]} for y in x["inputs"]
                ],
                "output": [
                    {"name": y["name"], "type": y["type"]} for y in x["outputs"]
                ],
            }
            for x in in_dict["abi"]
            if x["type"] == "function"
        ]
    return out_dict


def process_folder(folder_path: str) -> list:
    result = []
    for file_name in os.listdir(folder_path):
        if False == os.path.isfile(os.path.join(folder_path, file_name)):
            continue
        result.append(process_file(os.path.join(folder_path, file_name)))
    return result


def fetch_function_data(arg: str) -> dict:
    if os.path.isdir(arg):
        result = process_folder(arg)
    elif os.path.isfile(arg):
        result = process_file(arg)
    else:
        raise Exception("Invalid input", arg)
        sys.exit(2)
    return result
