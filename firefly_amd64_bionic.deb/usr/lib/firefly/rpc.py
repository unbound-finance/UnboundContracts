#!/usr/bin/python3
from subprocess import Popen, PIPE
## RPC Call helpers

def send_rpc(rpc, port):
    process = Popen(['curl', '-X', 'POST', '--data', rpc, 'localhost:' + str(port)], stdout=PIPE, stderr=PIPE)
    stdout, stderr = process.communicate()
    return stdout

def rpc_call(method, params):
    return ( "{" f""""jsonrpc":"2.0","id":0,"method":"{method}","params":[{params}]""" "}" )

def firefly_addAccount(privKey, balance):
    return rpc_call("firefly_addAccount", "{" f""""key":{privKey},"balance":{balance}""" "}")

def firefly_setGasLimit(gasLimit):
    return rpc_call("firefly_setGasLimit", f"{gasLimit}")

def firefly_setGasPrice(gasPrice):
    return rpc_call("firefly_setGasPrice", f"{gasPrice}")

def firefly_setNetworkId(networkId):
    return rpc_call("firefly_setNetworkId", f"{networkId}")

def firefly_genesisBlock(time):
    return rpc_call("firefly_genesisBlock", f"{time}")

def firefly_setVMErrors(value):
    return rpc_call("firefly_setVMErrors", f"{value}")
